﻿namespace RollCall.MVC.ViewModels.Subjects
{
    using RollCall.MVC.Data.Models;
    public class AddUsersToSubjectVM
    {
        public User User { get; set; }
        public bool IsInSubject { get; set; }
    }
}
