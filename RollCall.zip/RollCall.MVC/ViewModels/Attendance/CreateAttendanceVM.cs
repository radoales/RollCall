﻿namespace RollCall.MVC.ViewModels.Attendance
{
    public class CreateAttendanceVM
    {
        public string UserId { get; set; }

        public int ClassId { get; set; }
    }
}
